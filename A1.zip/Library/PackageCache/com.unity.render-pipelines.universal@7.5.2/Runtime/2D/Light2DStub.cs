using System;

namespace UnityEngine.Experimental.Rendering.LWRP
{
    [Obsolete("LWRP -> Universal (UnityUpgradable) -> UnityEngine.Experimental.Rendering.Universal.Light2D", true)]
    public class Light2D
    { }
}
